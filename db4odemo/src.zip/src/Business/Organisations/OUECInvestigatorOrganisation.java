/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Business.Organisations;

import Business.Role.OUECInvestigatorRole;
import Business.Role.Role;
import java.util.ArrayList;

/**
 *
 * @author aamrah
 */
public class OUECInvestigatorOrganisation extends Organisation{

    public OUECInvestigatorOrganisation() {
        super(Organisation.Type.OUECInvestigatorOrganisation.getValue());
    }

    
    @Override
    public ArrayList<Role> getSupportedRole() {
     ArrayList<Role> roles =new ArrayList();
     roles.add(new OUECInvestigatorRole());
     return roles;
    }
    
}
